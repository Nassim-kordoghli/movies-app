import App from './_app'

export default function Home() {
  return (
    <>
      <App />
     </>
  )
}
